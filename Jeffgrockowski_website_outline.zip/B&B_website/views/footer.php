<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> B & B, Inc.
    </p>
</footer>
</body>
</html>