<!DOCTYPE html>
<html>

<head> 

    <title>B & B</title>
    <meta>
    <link rel="stylesheet" href ="scss/main.css">
</head>


<body>
<header><h1 id = 'main_logo'>B & B</h1></header>