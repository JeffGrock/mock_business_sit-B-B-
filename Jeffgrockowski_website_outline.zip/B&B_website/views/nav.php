<nav id = 'nav'>
    <ul>
        <li><a href ='../index.php' >Homepage</a></li>
        <li><a href='../beer_list/index.php'>beer list</a></li>
        <li><a href='../calender/index.php'>calendar</a></li>
        <li><a href='../bakery/index.php'>bakery</a></li>
        <li><a href='../cart/index.php'>cart</a></li>
    </ul>
</nav>
