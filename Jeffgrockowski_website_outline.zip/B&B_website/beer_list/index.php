<?php include '../views/header.php'?>
<?php include '../views/nav.php'?>
<style>
    <?php include '../scss/main.css'?>
</style>


<main>

    <section class = "beer_listing">
        <h2>sample beer listing</h2>
        <div class = "image_container">
            <img src = "../images/beer_image.jpg" alt = "beer image"><img>
        </div>
        <p>
            details: <br>
            IBU: <br>
            alcohole %: <br>
            price: <br>
        </p>
    </section>

    <section class = "beer_listing">
        <h2>the next listing etc...</h2>
        <div class = "image_container">
            <img src = "../images/beer_image.jpg" alt = "beer image"><img>
        </div>
        <p>
            details: <br>
            IBU: <br>
            alcohole %: <br>
            price: <br>
        </p>
    </section>
</main>

<?php include '../views/footer.php'; ?>