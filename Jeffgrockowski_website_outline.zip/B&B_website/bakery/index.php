<?php include '../views/header.php'?>
<?php include '../views/nav.php'?>
<style><?php include '../scss/main.css'?></style>

<main>

    <?php include './menu.php'?>

</main>

<?php include '../views/footer.php'; ?>