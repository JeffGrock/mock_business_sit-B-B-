<section class ="menu_item">
    <h2>Sample menue item</h2>
    <P>
        item details:<br>
        price:<br>
        best drink pairings:<br>
    </P>

</section>

<section class ="menu_item">
    <h2>Sample menue item</h2>
    <P>
        item details:<br>
        price:<br>
        best drink pairings:<br>
    </P>

</section>